package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonBack = (Button) findViewById(R.id.Button16);
        buttonBack.setonClickListener(this);
    }

    public void onClick(view view) {
        Intent i;
        i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }
}