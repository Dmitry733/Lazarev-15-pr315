package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity2 extends Activity implements View.OnClickListener {

    File directory;
    final int TYPE_PHOTO = 1;
    final int TYPE_VIDEO = 2;

    final int REQUEST_CODE_PHOTO = 1;
    final int REQUEST_CODE_VIDEO = 2;

    final String TAG = "myLogs";

    ImageView ivPhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        createDirectory();
        ImageView IvPhoto = (ImageView) findViewById(R.id.imageView7);
    }

    public void onClick(View view) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, generateFileUri(TYPE_PHOTO));
        startActivityForResult(intent, REQUEST_CODE_PHOTO);
        ImageView button2 =(ImageView) findViewById(R.id.imageView7);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent intent) {
        if(requestCode == REQUEST_CODE_PHOTO) {
            if(resultCode == RESULT_OK) {
                if(intent == null) {
                    Log.d(TAG, "Intent is null");
                } else{
                    Log.d(TAG, "Photo uri: "+ intent.getData());
                    Bundle bndl = intent.getExtras();
                    if(bndl != null) {
                        Object obj = intent.getExtras().get("data");
                        if(obj instanceof Bitmap) {
                            Bitmap bitmap = (Bitmap) obj;
                            Log.d(TAG, "bitmap "+ bitmap.getWidth() + " x "
                                    + bitmap.getHeight());
                            ivPhoto.setImageBitmap(bitmap);
                        }
                    }
                }
            } else if(resultCode == RESULT_CANCELED) {
                Log.d(TAG, "Canceled");
            }
        }

        if(requestCode == REQUEST_CODE_VIDEO) {
            if(resultCode == RESULT_OK) {
                if(intent == null) {
                    Log.d(TAG, "Intent is null");
                } else{
                    Log.d(TAG, "Video uri: "+ intent.getData());
                }
            } else if(resultCode == RESULT_CANCELED) {
                Log.d(TAG, "Canceled");
            }
        }
    }

    private Uri generateFileUri(int type) {
        File file = null;
        switch(type) {
            case TYPE_PHOTO:
                file = new File(directory.getPath() + "/"+ "photo_"
                        + System.currentTimeMillis() + ".jpg");
                break;
            case TYPE_VIDEO:
                file = new File(directory.getPath() + "/"+ "video_"
                        + System.currentTimeMillis() + ".mp4");
                break;
        }
        Log.d(TAG, "fileName = "+ file);
        return Uri.fromFile(file);
    }

    private void createDirectory() {
        directory = new File(
                Environment
                        .getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "MyFolder");
        if(!directory.exists())
            directory.mkdirs();
    }
}